import React from 'react';
import Cylinder from './Canvas/Cylinder';
import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/css/bootstrap.css';



const App = () => {
  return (
    <div  style={{ textAlign: 'center', backgroundColor: '#add8e6', WebkitTextSizeAdjust: 'initial', fontSize: 'larger' }}>
      <Cylinder />
    </div>
  );
};

export default App;
